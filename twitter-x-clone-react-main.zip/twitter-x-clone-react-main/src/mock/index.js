export const whoFollowUsers = [
    {
        id: 3,
        username: 'FRIZtoja',
        fullName: 'Karol FRIZ Wiśniewski',
        avatar: 'https://pbs.twimg.com/profile_images/1555824048692764673/ZtFAGmWx_bigger.jpg',
        
    },
    {
        id: 4,
        username: 'Faaaustii',
        fullName: 'Fausti',
        avatar: 'https://pbs.twimg.com/profile_images/1587036802023571458/f_SxKael_bigger.jpg',
        
    },
    {
        id: 5,
        username: 'polasieczko',
        fullName: 'Pola',
        avatar: 'https://pbs.twimg.com/profile_images/1722345044114362368/a6YNhZCh_bigger.jpg',
        verified: true,
        
    },
]