export default function Notifications() {
    return(
        <div>Notifications Component</div>
    )
}