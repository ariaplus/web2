export default function Explore() {
    return(
        <div>Explore Component</div>
    )
}