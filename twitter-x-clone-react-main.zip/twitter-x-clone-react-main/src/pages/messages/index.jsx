export default function Messages() {
    return(
        <div>Message Component</div>
    )
}