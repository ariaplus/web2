export default function Communities() {
    return(
        <div>Communities Component</div>
    )
}