export default function NotFound() {
  return (
    <div className="bg-red-200 text-red-600 flex items-center justify-center p-5">
      Not Found
    </div>
  )
}
