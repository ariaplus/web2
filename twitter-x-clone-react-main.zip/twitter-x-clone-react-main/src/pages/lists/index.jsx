export default function Lists() {
    return(
        <div>List Component</div>
    )
}