import Button from "~/components/button"

export default function New() {
    return (
        <div className="py-4 w-[90%]">
            <Button size="large">Post</Button>
        </div>
    )
}