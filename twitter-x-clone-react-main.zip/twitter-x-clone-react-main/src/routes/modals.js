import AppearanceModal from "~/modals/appearance";

const modals = [
    {
        name: 'appearance',
        element: AppearanceModal
    }
]

export default modals