export default function Content({children}) {
    return (
        <div>
            {children}
        </div>
    )
}

